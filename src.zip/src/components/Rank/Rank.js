import React from 'react';

const Rank = () => {
  return(
    <div>
      <div className='white f3'>
        {'Weiner your ranking is...'}
      </div>
      <div className='white f2'>
        {'#3'}
      </div>
    </div>

  );
}
export default Rank;
